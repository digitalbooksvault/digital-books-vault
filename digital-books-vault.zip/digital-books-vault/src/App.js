import React from 'react';
import DigitalBooksVault from './SimpleWebsite';

function App() {
  return <DigitalBooksVault />;
}

export default App;
