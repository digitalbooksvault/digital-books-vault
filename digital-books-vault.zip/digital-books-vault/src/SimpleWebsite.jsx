import React, { useState, useEffect, useRef } from 'react';
import { Menu, X, Music, BookOpen, Headphones } from 'lucide-react';

const DigitalBooksVault = () => {
  const [currentPage, setCurrentPage] = useState('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isMusicPlaying, setIsMusicPlaying] = useState(true);
  const audioRef = useRef(null);

  const musicTracks = {
    home: 'https://cdn.pixabay.com/download/audio/2022/03/10/audio_98fbb1c2b8.mp3',
    ebooks: 'https://cdn.pixabay.com/download/audio/2022/02/04/audio_b90c6f57ba.mp3',
    audiobooks: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_d0a8b6bc00.mp3',
    pricing: 'https://cdn.pixabay.com/download/audio/2022/03/22/audio_b4a8c7e91f.mp3',
    contact: 'https://cdn.pixabay.com/download/audio/2022/02/15/audio_f8a0d9c2e1.mp3',
  };

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.src = musicTracks[currentPage] || musicTracks.home;
      if (isMusicPlaying) {
        audioRef.current.play().catch(() => {});
      }
    }
  }, [currentPage, isMusicPlaying]);

  const books = [
    { id: 1, title: 'Sakura Dreams', author: 'Yuki Tanaka', price: 299, type: 'ebook', cover: '📚' },
    { id: 2, title: 'Neon Hearts', author: 'Kim Min-jun', price: 389, type: 'audiobook', cover: '🎧' },
    { id: 3, title: 'Midnight Echoes', author: 'Sora Aiko', price: 319, type: 'ebook', cover: '📖' },
    { id: 4, title: 'Digital Dreams', author: 'Nova Verse', price: 349, type: 'audiobook', cover: '🎵' },
  ];

  const pricingPlans = [
    {
      name: 'Free',
      price: 0,
      features: ['5 Books/month', 'Limited Selection', '1 Device', 'Ads Included'],
      color: 'from-gray-600 to-slate-600'
    },
    {
      name: 'Starter',
      price: 199,
      features: ['10 Books/month', 'Basic Support', '1 Device'],
      color: 'from-blue-600 to-cyan-600'
    },
    {
      name: 'Premium',
      price: 499,
      features: ['Unlimited Books', 'Priority Support', '5 Devices', 'Offline Reading'],
      color: 'from-purple-600 to-pink-600',
      popular: true
    },
    {
      name: 'VIP',
      price: 799,
      features: ['Everything Premium', 'Early Access', '10 Devices', '24/7 Support'],
      color: 'from-orange-600 to-red-600'
    }
  ];

  // HOME PAGE
  const HomePage = () => (
    <div className="bg-gradient-to-b from-slate-950 via-purple-950 to-slate-950 min-h-screen px-4 md:px-8 pt-32 pb-20">
      <div className="max-w-6xl mx-auto">
        {/* Hero Section */}
        <div className="text-center mb-20">
          <h1 className="text-5xl md:text-6xl font-black mb-6">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-400">
              Digital Books Vault
            </span>
          </h1>
          <p className="text-gray-300 text-lg mb-8 max-w-2xl mx-auto">
            Discover amazing ebooks and audiobooks inspired by anime and K-drama culture
          </p>
          <div className="flex justify-center gap-4 text-3xl opacity-70">
            <span>📚</span>
            <span>✨</span>
            <span>🎧</span>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-20">
          <div className="bg-slate-800/50 border border-purple-500/30 rounded-xl p-6 text-center">
            <p className="text-3xl font-bold text-cyan-400">500+</p>
            <p className="text-gray-300 mt-2">Books Collection</p>
          </div>
          <div className="bg-slate-800/50 border border-purple-500/30 rounded-xl p-6 text-center">
            <p className="text-3xl font-bold text-pink-400">24/7</p>
            <p className="text-gray-300 mt-2">Available Access</p>
          </div>
          <div className="bg-slate-800/50 border border-purple-500/30 rounded-xl p-6 text-center">
            <p className="text-3xl font-bold text-purple-400">⭐4.8</p>
            <p className="text-gray-300 mt-2">User Rating</p>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex gap-4 justify-center mb-20 flex-wrap">
          <button
            onClick={() => setCurrentPage('ebooks')}
            className="px-8 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-bold hover:opacity-90 transition flex items-center gap-2"
          >
            <BookOpen size={20} /> Explore eBooks
          </button>
          <button
            onClick={() => setCurrentPage('audiobooks')}
            className="px-8 py-3 bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-lg font-bold hover:opacity-90 transition flex items-center gap-2"
          >
            <Headphones size={20} /> Explore Audiobooks
          </button>
        </div>

        {/* Featured Books Preview */}
        <div>
          <h2 className="text-3xl font-bold text-white mb-8">Featured Books</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {books.map(book => (
              <div key={book.id} className="bg-slate-800/50 border border-purple-500/30 rounded-lg p-6 hover:border-purple-400/50 transition">
                <div className="text-5xl mb-4">{book.cover}</div>
                <h3 className="text-lg font-bold text-white mb-2">{book.title}</h3>
                <p className="text-sm text-gray-400 mb-3">{book.author}</p>
                <p className="text-cyan-400 font-bold">₹{book.price}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  // E-BOOKS PAGE
  const EBooksPage = () => (
    <div className="bg-gradient-to-b from-slate-950 via-purple-950 to-slate-950 min-h-screen px-4 md:px-8 pt-32 pb-20">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-white mb-4">📚 E-Books Collection</h1>
        <p className="text-gray-400 mb-12">Dive into thousands of stories</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {books.filter(b => b.type === 'ebook').concat(
            { id: 5, title: 'Fantasy Quest', author: 'Aria Winds', price: 279, type: 'ebook', cover: '⚔️' },
            { id: 6, title: 'Love Beyond', author: 'Emma Rose', price: 299, type: 'ebook', cover: '💕' }
          ).map(book => (
            <div key={book.id} className="bg-slate-800/50 border border-purple-500/30 rounded-xl p-6 hover:border-cyan-400/50 transition">
              <div className="text-6xl mb-4">{book.cover}</div>
              <h3 className="text-xl font-bold text-white mb-2">{book.title}</h3>
              <p className="text-gray-400 mb-4">{book.author}</p>
              <div className="flex justify-between items-center">
                <span className="text-2xl font-bold text-cyan-400">₹{book.price}</span>
                <button className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm font-bold transition">
                  Buy Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // AUDIOBOOKS PAGE
  const AudioBooksPage = () => (
    <div className="bg-gradient-to-b from-slate-950 via-purple-950 to-slate-950 min-h-screen px-4 md:px-8 pt-32 pb-20">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-white mb-4">🎧 Audiobooks Collection</h1>
        <p className="text-gray-400 mb-12">Listen to amazing stories anytime, anywhere</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {books.filter(b => b.type === 'audiobook').concat(
            { id: 7, title: 'Mystery Unfolded', author: 'Detective Lee', price: 359, type: 'audiobook', cover: '🔍' },
            { id: 8, title: 'Sci-Fi Adventure', author: 'Future King', price: 379, type: 'audiobook', cover: '🚀' }
          ).map(book => (
            <div key={book.id} className="bg-slate-800/50 border border-purple-500/30 rounded-xl p-6 hover:border-cyan-400/50 transition">
              <div className="text-6xl mb-4">{book.cover}</div>
              <h3 className="text-xl font-bold text-white mb-2">{book.title}</h3>
              <p className="text-gray-400 mb-4">{book.author}</p>
              <div className="flex justify-between items-center">
                <span className="text-2xl font-bold text-cyan-400">₹{book.price}</span>
                <button className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm font-bold transition">
                  Buy Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // PRICING PAGE
  const PricingPage = () => (
    <div className="bg-gradient-to-b from-slate-950 via-purple-950 to-slate-950 min-h-screen px-4 md:px-8 pt-32 pb-20">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-white text-center mb-4">💎 Subscription Plans</h1>
        <p className="text-gray-400 text-center mb-16">Choose the perfect plan for you</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {pricingPlans.map((plan, idx) => (
            <div key={idx} className={`bg-slate-800/50 border-2 rounded-xl p-8 ${plan.popular ? 'border-pink-500 ring-2 ring-pink-500/30' : 'border-purple-500/30'}`}>
              {plan.popular && (
                <div className="bg-pink-600 text-white px-4 py-1 rounded-full text-sm font-bold mb-4 w-fit">
                  Most Popular
                </div>
              )}
              {plan.badge && (
                <div className="bg-green-600 text-white px-4 py-1 rounded-full text-sm font-bold mb-4 w-fit">
                  {plan.badge}
                </div>
              )}
              <h3 className="text-2xl font-bold text-white mb-4">{plan.name}</h3>
              <p className="text-4xl font-bold text-cyan-400 mb-6">
                {plan.price === 0 ? 'FREE' : `₹${plan.price}`}
                {plan.price !== 0 && <span className="text-lg text-gray-400">/month</span>}
              </p>

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, i) => (
                  <li key={i} className="text-gray-300 flex items-center gap-2">
                    <span className="text-cyan-400">✓</span> {feature}
                  </li>
                ))}
              </ul>

              <button className={`w-full py-3 rounded-lg font-bold transition ${
                plan.popular
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:opacity-90'
                  : plan.price === 0
                  ? 'bg-gradient-to-r from-green-600 to-teal-600 text-white hover:opacity-90'
                  : 'border-2 border-purple-500/50 text-purple-300 hover:border-purple-400'
              }`}>
                {plan.price === 0 ? 'Start Free' : 'Get Started'}
              </button>
            </div>
          ))}
        </div>

        {/* Payment Info */}
        <div className="bg-gradient-to-r from-purple-900/50 to-pink-900/50 border border-purple-500/30 rounded-xl p-8 text-center">
          <h3 className="text-2xl font-bold text-white mb-4">Ready to Get Started?</h3>
          <p className="text-gray-300 mb-6">Contact us to make payment and get instant access</p>
          <div className="bg-slate-900/50 border border-cyan-500/50 rounded-lg p-6 inline-block">
            <p className="text-sm text-gray-400 mb-2">Phone Number for Payment:</p>
            <p className="text-4xl font-black text-cyan-400">📱 9701955780</p>
            <p className="text-xs text-gray-400 mt-3">Available 24/7 for payment inquiries</p>
          </div>
        </div>
      </div>
    </div>
  );

  // CONTACT PAGE
  const ContactPage = () => (
    <div className="bg-gradient-to-b from-slate-950 via-purple-950 to-slate-950 min-h-screen px-4 md:px-8 pt-32 pb-20">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-white text-center mb-4">Contact Us</h1>
        <p className="text-gray-400 text-center mb-12">We're here to help!</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Contact Form */}
          <div className="bg-slate-800/50 border border-purple-500/30 rounded-xl p-8">
            <h3 className="text-2xl font-bold text-white mb-6">Send us a Message</h3>
            <form className="space-y-4">
              <input
                type="text"
                placeholder="Your Name"
                className="w-full bg-slate-700/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400"
              />
              <input
                type="email"
                placeholder="Your Email"
                className="w-full bg-slate-700/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400"
              />
              <textarea
                placeholder="Your Message"
                rows="5"
                className="w-full bg-slate-700/50 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400"
              />
              <button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg font-bold hover:opacity-90 transition">
                Send Message
              </button>
            </form>
          </div>

          {/* Contact Info */}
          <div className="space-y-6">
            <div className="bg-slate-800/50 border border-purple-500/30 rounded-xl p-6">
              <h4 className="text-xl font-bold text-white mb-3">📱 Phone</h4>
              <p className="text-2xl font-bold text-cyan-400">9701955780</p>
              <p className="text-sm text-gray-400 mt-2">Available 24/7</p>
            </div>

            <div className="bg-slate-800/50 border border-purple-500/30 rounded-xl p-6">
              <h4 className="text-xl font-bold text-white mb-3">✉️ Email</h4>
              <p className="text-cyan-400">digitalbooksvault@gmail.com</p>
            </div>

            <div className="bg-slate-800/50 border border-purple-500/30 rounded-xl p-6">
              <h4 className="text-xl font-bold text-white mb-3">⏰ Hours</h4>
              <p className="text-gray-300">Monday - Sunday: 24/7</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-950">
      <audio ref={audioRef} loop volume={0.4} />

      {/* Navigation Bar */}
      <nav className="fixed top-0 w-full bg-gradient-to-r from-slate-900 via-purple-900 to-slate-900 border-b border-purple-700/30 backdrop-blur-md z-50">
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-4">
          <div className="flex justify-between items-center">
            
            {/* Logo */}
            <button
              onClick={() => setCurrentPage('home')}
              className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-cyan-400 hover:opacity-80 transition"
            >
              📚 Digital Books Vault
            </button>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-8">
              <button
                onClick={() => setCurrentPage('home')}
                className={`font-semibold transition ${currentPage === 'home' ? 'text-pink-400' : 'text-gray-300 hover:text-white'}`}
              >
                Home
              </button>
              <button
                onClick={() => setCurrentPage('ebooks')}
                className={`font-semibold transition ${currentPage === 'ebooks' ? 'text-pink-400' : 'text-gray-300 hover:text-white'}`}
              >
                eBooks
              </button>
              <button
                onClick={() => setCurrentPage('audiobooks')}
                className={`font-semibold transition ${currentPage === 'audiobooks' ? 'text-pink-400' : 'text-gray-300 hover:text-white'}`}
              >
                Audiobooks
              </button>
              <button
                onClick={() => setCurrentPage('pricing')}
                className={`font-semibold transition ${currentPage === 'pricing' ? 'text-pink-400' : 'text-gray-300 hover:text-white'}`}
              >
                Pricing
              </button>
              <button
                onClick={() => setCurrentPage('contact')}
                className={`font-semibold transition ${currentPage === 'contact' ? 'text-pink-400' : 'text-gray-300 hover:text-white'}`}
              >
                Contact
              </button>
            </div>

            {/* Right Actions */}
            <div className="flex items-center gap-4">
              <button
                onClick={() => setIsMusicPlaying(!isMusicPlaying)}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-pink-600 to-purple-600 text-white rounded-lg hover:opacity-90 transition font-semibold"
                title={isMusicPlaying ? 'Click to mute music' : 'Click to play music'}
              >
                <Music size={18} />
                <span className="hidden md:inline text-sm">{isMusicPlaying ? 'Music ON' : 'Music OFF'}</span>
              </button>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="md:hidden text-gray-300 hover:text-white"
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="md:hidden mt-4 space-y-3 border-t border-purple-700/30 pt-4">
              {[
                { label: 'Home', key: 'home' },
                { label: 'eBooks', key: 'ebooks' },
                { label: 'Audiobooks', key: 'audiobooks' },
                { label: 'Pricing', key: 'pricing' },
                { label: 'Contact', key: 'contact' }
              ].map(item => (
                <button
                  key={item.key}
                  onClick={() => {
                    setCurrentPage(item.key);
                    setIsMenuOpen(false);
                  }}
                  className="block w-full text-left px-4 py-2 text-gray-300 hover:text-pink-400 transition"
                >
                  {item.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </nav>

      {/* Page Content */}
      <div className="pt-16">
        {currentPage === 'home' && <HomePage />}
        {currentPage === 'ebooks' && <EBooksPage />}
        {currentPage === 'audiobooks' && <AudioBooksPage />}
        {currentPage === 'pricing' && <PricingPage />}
        {currentPage === 'contact' && <ContactPage />}
      </div>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-purple-700/30 py-8 text-center text-gray-400">
        <p>✨ Digital Books Vault © 2024 | Phone: 9701955780 | For anime & K-drama lovers 💜</p>
      </footer>
    </div>
  );
};

export default DigitalBooksVault;
